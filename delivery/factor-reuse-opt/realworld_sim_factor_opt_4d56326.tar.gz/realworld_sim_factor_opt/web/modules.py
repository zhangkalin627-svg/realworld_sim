"""Web 版模块注册表：每个模块声明参数表单 schema + 运行函数。加新模块 = 在 MODULES 里加一项。
架构约定（面向中期目标"自由组合拼设备 + 长时连续运行"）：参数是纯 JSON dict、运行函数无状态(JSON in → JSON out)，
未来"拼设备"= 部件图/连接拓扑的 JSON 由图执行器组合多个模块runner；长任务靠任务表持久化 + 加速仿真，runner 契约不变。
运行函数签名: run(params: dict, progress: callable(fraction)) -> {"lines": [str], "warnings": [str], "plots": [{"title", "svg"}], "raw": dict}
图用服务器端 matplotlib 渲染成 SVG 字符串，前端内联显示，不需要 JS 图表库。"""
import io
import numpy as np
import matplotlib
matplotlib.use("Agg")                    # 服务器无显示环境
import matplotlib.pyplot as plt

# Web 绘图路径注册中文字库（与 rw/viz.py 同口径；kabu499 发现只跑电路模块时缺字）
import os as _os
_fp = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "fonts", "NotoSansSC-Regular.otf")
if _os.path.exists(_fp):
    matplotlib.font_manager.fontManager.addfont(_fp)
for _f in ("Noto Sans SC", "Noto Sans CJK SC", "Noto Sans CJK JP", "WenQuanYi Zen Hei", "Microsoft YaHei", "SimHei"):
    if any(_f in f.name for f in matplotlib.font_manager.fontManager.ttflist):
        plt.rcParams["font.sans-serif"] = [_f, "DejaVu Sans"]
        break
plt.rcParams["axes.unicode_minus"] = False


def _clean(o):
    """递归清理: 非有限浮点(NaN/Inf, 如未达温的 t8/5) 转 None，保证 JSON 可序列化。"""
    import math
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    return o


def _f2(x, nd=2):
    return f"{x:.{nd}f}" if isinstance(x, (int, float)) and x == x else "—"   # NaN 显示为 —


def _num(x, nd=0, scale=1.0):
    """NaN/None 安全的数值格式化（如功率为 0 时效率是 0/0=NaN）。"""
    return f"{x * scale:.{nd}f}" if isinstance(x, (int, float)) and x == x else "—"


def _svg(fig):
    b = io.StringIO()
    fig.savefig(b, format="svg", bbox_inches="tight")
    plt.close(fig)
    return b.getvalue()


def _plot(sim, kind, title):
    from rw import viz
    fig = plt.figure(figsize=(5.2, 4.0))
    ax = fig.add_subplot(111)
    if kind == "temp":
        viz.plot_field(ax, sim, sim.T_end_heat, "inferno", "°C", 25, max(1000, float(sim.T_end_heat.max())), fig)
    elif kind == "hrc":
        viz.plot_field(ax, sim, sim.HRC, viz.HRC_CMAP, "HRC", 18, 60, fig)
    elif kind == "curve":
        viz.plot_curves(ax, sim)
    elif kind == "line":
        viz.plot_hardness_line(ax, sim)
    ax.set_title(title)
    fig.tight_layout()
    return {"title": title, "svg": _svg(fig)}


def induction_geometry(params):
    """Shared fast geometry preflight; no solver work or parameter clamping."""
    from rw.induction import BottleNeckGeometry
    defaults = dict(neck_od=22, wall=3, neck_len=50, zone=20, coil_id=30, coil_h=25)
    return BottleNeckGeometry(**{k: params.get(k, v) for k, v in defaults.items()})


def run_induction(params, progress, checkpoint=None, resume=None):
    """感应淬火：参数对齐桌面版①页。慢任务（非线性约 ×3），由任务线程跑。支持断点续算 (v0.25)。"""
    if resume is not None:
        if not isinstance(resume, dict) or resume.get("params_fingerprint") != _ind_fingerprint(params):
            raise ValueError("续算参数指纹不匹配，请使用原参数或明确新建任务")
    from rw.induction import InductionQuenchSim, find_power
    f = lambda k, d: float(params.get(k, d))
    g = induction_geometry(params)
    kw = dict(geom=g, freq=f("freq", 20) * 1e3, t_heat=f("t_heat", 3.0),
              t_quench=f("t_quench", 3.0), t_air=f("t_air", 6.0),
              medium=params.get("medium", "water_spray"),
              mur_cold=f("mur_cold", 20.0), nonlinear=bool(params.get("nonlinear", False)),
              accel=params.get("speed", "accurate") == "fast")
    # 入参校验（豆包巡检 P1-1/P1-2：直接调 runner 时无 server schema 防线）
    from rw import materials as _M
    from rw.em.bh import FLUX_MATERIALS as _FM
    for k, lo, hi in (("t_heat", 0.01, 600), ("t_quench", 0.0, 600), ("t_air", 0.0, 600),
                      ("target", 100.0, 1600.0), ("power_kw", 0.0, 500.0), ("mur_cold", 1.0, 500.0),
                      ("freq", 0.1, 1000.0)):
        if k in params and not (lo <= f(k, 0.0) <= hi):
            raise ValueError(f"感应淬火参数 {k}={params[k]!r} 超出范围 [{lo}, {hi}]")
    if kw["medium"] not in _M.QUENCHANTS:
        raise ValueError(f"未知淬火介质 {kw['medium']!r}（可选：{', '.join(_M.QUENCHANTS)}）")
    ck = params.get("conc")
    if ck:
        if str(ck).lower() not in _FM:
            raise ValueError(f"未知导磁体材料 {ck!r}（可选：{', '.join(_FM)}）")
        from rw.em.conc import Concentrator
        kw["conc"] = Concentrator(str(ck).lower())
    if params.get("mode", "target") == "target":
        target = f("target", 900.0)
        progress(0.02)
        kw["power_kw"] = find_power(target, **kw)
    else:
        kw["power_kw"] = f("power_kw", 6.0)
    sim = InductionQuenchSim(**kw)
    r = _clean(sim.run(progress=lambda f: progress(0.05 + 0.95 * f),
                       checkpoint=checkpoint and (lambda st: checkpoint({**st, "params_fingerprint": _ind_fingerprint(params)})),
                       resume=resume))
    lines = [
        f"频率 {_num(r['freq_kHz'])} kHz，工件吸收 {_num(r['power_kW'], 2)} kW",
        f"透入深度：冷态 {_num(r['skin_cold_mm'], 2)} mm，热态(>居里点) {_num(r['skin_hot_mm'], 2)} mm",
        f"加热结束：外表面 {_num(r['T_surf_end_heat'])}°C，内孔 {_num(r['T_inner_end_heat'])}°C，最高 {_num(r['T_max'])}°C",
        f"线圈电流约 {_num(r['coil_current_A'])} A(有效值)，线圈铜损约 {_num(r['coil_loss_kW'], 2)} kW，电效率约 {_num(r['efficiency'], 0, 100)}%",
        f"淬火：{r['medium']}，t8/5 外表面 {_f2(r['t85_surface'])} s / 内孔 {_f2(r['t85_inner'])} s",
        f"硬度(估算)：外表面 {_num(r['HRC_surface'])} HRC，内孔 {_num(r['HRC_inner'])} HRC",
        f"有效硬化层 (≥50 HRC)：{_num(r['case_depth_mm'], 2)} mm" + ("，已淬透" if r['through_hardened'] else ""),
    ]
    if r.get("nonlinear"):
        lines.insert(1, "磁导率：非线性 B-H(含居里点)" + (f"；导磁体 {r['conc']}，其损耗 {_num(r['conc_loss_kW'], 2)} kW" if r.get("conc") else ""))
    plots = [_plot(sim, "temp", "加热结束温度场"), _plot(sim, "hrc", "淬火后硬度（估算）"),
             _plot(sim, "curve", "监测点温度 / 线圈电流"), _plot(sim, "line", "淬火区中部：硬度随深度")]
    return {"lines": lines, "warnings": r["warnings"], "plots": plots, "raw": r}


def _ind_fingerprint(params):
    """断点续算参数指纹：几何/频率/功率/时间/介质任一变化都不能沿用旧检查点。"""
    keys = ("neck_od", "wall", "neck_len", "zone", "coil_id", "coil_h", "freq", "mode", "target",
            "power_kw", "t_heat", "t_quench", "t_air", "medium", "mur_cold", "nonlinear", "speed", "conc")
    return "|".join(str(params.get(k)) for k in keys)


def run_materials(params, progress):
    """材料库：45 钢关键参数 + 淬火介质表（只读）。"""
    from rw import materials as M
    progress(1.0)
    s = M.STEEL_45
    lines = [f"{s['name']}：密度 {s['density']:.0f} kg/m³，Ac1 {s['Ac1']:.0f}°C，Ac3 {s['Ac3']:.0f}°C，"
             f"居里点 {s['T_curie']:.0f}°C，Ms {s['Ms']:.0f}°C，熔点 {s['T_melt']:.0f}°C", "", "淬火介质："]
    for k, q in M.QUENCHANTS.items():
        lines.append(f"· {q['name']}（{k}）：槽温 {q['T_bath']:.0f}°C，峰值换热系数约 {max(q['h']):.0f} W/m²K")
    return {"lines": lines, "warnings": [], "plots": [], "raw": {}}


def _w3d(params, progress):
    from .w3d import run_world3d
    return run_world3d(params, progress)


def _plc(params, progress):
    from .plcsim import run_plc
    return run_plc(params, progress)


def _flow_net(params, progress):
    from .flowsim import run_flow_net
    return run_flow_net(params, progress)


def _flow_hammer(params, progress):
    from .flowsim import run_flow_hammer
    return run_flow_hammer(params, progress)


def _flow_jet(params, progress):
    from .flowsim import run_flow_jet
    return run_flow_jet(params, progress)


def _mcu(params, progress):
    from .mcusim import run_mcu
    return run_mcu(params, progress)


def _mcu_default_asm():
    from rw.mcu import firmware as FW
    return FW.HEATER_ASM


def _mcu_default_plc():
    from rw.mcu import firmware as FW
    return FW.PLC_IL


def _fluid_options(keys):
    from rw.world.fluids import FLUIDS
    return [{"v": k, "t": FLUIDS[k]["name"]} for k in keys]


def _plc_default_program():
    from rw.plc.demo import DEMO_IL
    return DEMO_IL


MODULES = [
    {"key": "induction", "name": "感应加热淬火", "desc": "瓶坯感应加热 + 喷淋淬火全过程：温度场、硬度、硬化层深度",
     "fields": [
         {"g": "工件 / 线圈 (mm)"},
         {"name": "neck_od", "label": "瓶口外径", "type": "number", "default": 22, "min": 5, "max": 200, "step": 0.5},
         {"name": "wall", "label": "壁厚", "type": "number", "default": 3, "min": 0.5, "max": 30, "step": 0.5},
         {"name": "neck_len", "label": "瓶颈长", "type": "number", "default": 50, "min": 10, "max": 300, "step": 1},
         {"name": "zone", "label": "淬火区长", "type": "number", "default": 20, "min": 2, "max": 100, "step": 1},
         {"name": "coil_id", "label": "线圈内径", "type": "number", "default": 30, "min": 6, "max": 300, "step": 0.5},
         {"name": "coil_h", "label": "线圈高度", "type": "number", "default": 25, "min": 2, "max": 200, "step": 1},
         {"g": "加热"},
         {"name": "freq", "label": "频率 (kHz)", "type": "select", "options": [5, 10, 20, 30, 50, 100, 200], "default": 20},
         {"name": "mode", "label": "方式", "type": "select", "options": [{"v": "target", "t": "给定目标温度（自动调功率）"}, {"v": "power", "t": "给定功率"}], "default": "target"},
         {"name": "target", "label": "外表面目标 °C", "type": "number", "default": 900, "min": 200, "max": 1600, "step": 10},
         {"name": "power_kw", "label": "工件吸收功率 kW", "type": "number", "default": 6, "min": 0.1, "max": 500, "step": 0.5},
         {"name": "t_heat", "label": "加热时间 s", "type": "number", "default": 3, "min": 0.1, "max": 60, "step": 0.1},
         {"name": "mur_cold", "label": "冷态有效磁导率 μr", "type": "number", "default": 20, "min": 1, "max": 200, "step": 1},
         {"name": "nonlinear", "label": "非线性 B-H + 居里点 (更准, 慢约 3 倍)", "type": "check", "default": False},
         {"name": "speed", "label": "速度档", "type": "select", "default": "accurate",
          "options": [{"v": "accurate", "t": "精确（默认，验证基线）"}, {"v": "fast", "t": "快速（×1.6-2.1；慢冷介质 t8/5 与频率两端 HRC 有偏差，精确结论用精确档）"}]},
         {"g": "冷却"},
         {"name": "medium", "label": "淬火介质", "type": "select", "default": "water_spray",
          "options": [{"v": "water_spray", "t": "清水喷淋"}, {"v": "polymer_spray", "t": "聚合物喷淋"}, {"v": "water_dip", "t": "清水浸入"}, {"v": "oil_dip", "t": "油浸"}, {"v": "air", "t": "空冷"}]},
         {"name": "t_quench", "label": "淬火时间 s", "type": "number", "default": 3, "min": 0.1, "max": 60, "step": 0.1},
         {"name": "t_air", "label": "空冷时间 s", "type": "number", "default": 6, "min": 0, "max": 600, "step": 1},
         {"name": "conc", "label": "导磁体", "type": "select", "default": "",
          "options": [{"v": "", "t": "无"}, {"v": "smc", "t": "smc"}, {"v": "sife", "t": "sife"}, {"v": "ferrite", "t": "ferrite"}]},
     ],
     "run": run_induction, "validate": induction_geometry, "ckpt": True},
    {"key": "materials", "name": "材料库", "desc": "45 钢关键相变点 + 淬火介质换热参数（只读查询）",
     "fields": [], "run": run_materials},
    {"key": "world3d", "name": "三维装配世界", "desc": "零件摆放 → 刚体物理仿真 → 受力体检（稳定性/梁应力/螺栓/轴承/赫兹），浏览器 3D 动画回放",
     "fields": [
         {"name": "preset", "label": "示例场景", "type": "select", "default": "工字钢梁桥",
          "options": ["钢板桥：两墩 + 铜块", "叠积木 外伸系数 0.95（应稳）", "叠积木 外伸系数 1.10（应倒）", "橡胶块在 22° 斜面（会倒）",
                      "钢块在 30° 斜面（会滑）", "钢块砸木板", "水里的浮沉", "焊接台架 + 偏载", "工字钢梁桥",
                      "壁挂支架 + 螺栓组", "轴承转子 3000rpm", "玻璃板断裂演示", "焊缝悬臂支架"]},
         {"name": "tmax", "label": "仿真时长上限 s", "type": "number", "default": 8, "min": 1, "max": 15, "step": 1},
     ],
     "run": _w3d},
    {"key": "plc", "name": "PLC 虚拟调试", "desc": "三菱 FX 指令表（含 STL 步进）+ 单工位感应淬火设备模型：整段运行 → 逻辑分析仪时序图 + 节拍/不合格统计",
     "fields": [
         {"name": "program", "label": "FX 指令表程序（可直接改，; 后为注释）", "type": "textarea", "default": _plc_default_program()},
         {"name": "p_air", "label": "气源气压 MPa", "type": "number", "default": 0.5, "min": 0.1, "max": 0.8, "step": 0.05},
         {"name": "scenario", "label": "演示剧本", "type": "select", "default": "normal",
          "options": [{"v": "normal", "t": "正常循环（0.3 s 按启动）"}, {"v": "estop", "t": "急停演示（中途急停 2 s 后复位重启）"}]},
         {"name": "estop_at", "label": "急停时刻 s（仅急停剧本）", "type": "number", "default": 8, "min": 1, "max": 170, "step": 1},
         {"name": "t_sim", "label": "运行时长 s", "type": "number", "default": 60, "min": 5, "max": 180, "step": 5},
     ],
     "run": _plc},
    {"key": "flow_net", "name": "流体·管网", "desc": "两工位并联喷淋管网：泵/阀/过滤器/软管/喷淋孔 → 流量分配、压力沿程、泵工作点、汽蚀/超速体检",
     "fields": [
         {"name": "fluid", "label": "介质", "type": "select", "default": "pag10", "options": _fluid_options(("pag10", "water", "oil_quench"))},
         {"name": "T", "label": "液温 °C", "type": "number", "default": 30, "min": 5, "max": 90, "step": 5},
         {"name": "speed", "label": "泵转速 % 额定", "type": "number", "default": 100, "min": 30, "max": 120, "step": 5},
         {"name": "dirty", "label": "吸入过滤器脏污 ×（1=干净）", "type": "number", "default": 1, "min": 0.5, "max": 40, "step": 1},
         {"name": "openB", "label": "B 路电磁阀开度 %", "type": "number", "default": 100, "min": 0, "max": 100, "step": 10},
         {"name": "holes", "label": "每路喷淋孔数", "type": "number", "default": 24, "min": 4, "max": 100, "step": 2},
         {"name": "dh", "label": "孔径 mm", "type": "number", "default": 1.2, "min": 0.5, "max": 4, "step": 0.1},
         {"name": "hose", "label": "软管内径 mm", "type": "number", "default": 10, "min": 5, "max": 20, "step": 1},
     ],
     "run": _flow_net},
    {"key": "flow_hammer", "name": "流体·水锤", "desc": "关阀冲击（特征线法）：最高/最低压力 vs 管材额定，汽穴判据，关阀时间影响",
     "fields": [
         {"name": "mat", "label": "管材", "type": "select", "default": "钢",
          "options": ["不锈钢", "钢", "铜", "PVC", "PE", "增强软管", "橡胶软管"]},
         {"name": "L", "label": "管长 m（阀到上游稳压点）", "type": "number", "default": 3, "min": 0.2, "max": 2000, "step": 1},
         {"name": "D", "label": "内径 mm", "type": "number", "default": 26, "min": 3, "max": 500, "step": 1},
         {"name": "e", "label": "壁厚 mm", "type": "number", "default": 2.0, "min": 0.2, "max": 30, "step": 0.5},
         {"name": "H", "label": "阀前稳压 bar（表压）", "type": "number", "default": 3.0, "min": 0.1, "max": 40, "step": 0.5},
         {"name": "K", "label": "阀全开阻力系数 K", "type": "number", "default": 20, "min": 0.5, "max": 5000, "step": 5},
         {"name": "tc", "label": "关阀时间 ms", "type": "number", "default": 25, "min": 1, "max": 20000, "step": 5},
         {"name": "rate", "label": "管/软管额定压力 bar", "type": "number", "default": 10, "min": 1, "max": 400, "step": 1},
     ],
     "run": _flow_hammer},
    {"key": "flow_jet", "name": "流体·放空与射流", "desc": "水箱底部开孔：放空时间（对照 Torricelli 解析）、射流轨迹/射程/冲击力",
     "fields": [
         {"name": "fluid", "label": "液体", "type": "select", "default": "water",
          "options": _fluid_options(("water", "pag10", "oil_quench", "gasoline", "glycerin", "mercury"))},
         {"name": "A", "label": "水箱截面积 m²", "type": "number", "default": 0.5, "min": 0.01, "max": 100, "step": 0.1},
         {"name": "H0", "label": "初始液位 m", "type": "number", "default": 1.0, "min": 0.05, "max": 30, "step": 0.1},
         {"name": "d", "label": "孔径 mm", "type": "number", "default": 12, "min": 1, "max": 100, "step": 1},
         {"name": "zh", "label": "孔离地高度 m", "type": "number", "default": 1.0, "min": 0, "max": 20, "step": 0.1},
         {"name": "ang", "label": "孔朝向 仰角 °", "type": "number", "default": 0, "min": -60, "max": 80, "step": 5},
     ],
     "run": _flow_jet},
    {"key": "mcu", "name": "单片机 + PLC 联合仿真", "desc": "ATmega328P 风格 AVR + FX PLC + 半桥电路：启动握手 → 软启动 → 短路过流保护 → 复位重启，关键时刻全部从波形量出",
     "fields": [
         {"name": "fw", "label": "固件", "type": "select", "default": "asm",
          "options": [{"v": "asm", "t": "汇编固件（默认加热器 PWM 控制）"}, {"v": "behav", "t": "行为级 Python 固件（快，不含指令计时）"}, {"v": "custom", "t": "自定义汇编（填下面）"}]},
         {"name": "custom_asm", "label": "自定义汇编固件（选了自定义才用）", "type": "textarea", "default": ""},
         {"name": "custom_plc", "label": "自定义 PLC 指令表（留空用默认加热工位程序）", "type": "textarea", "default": ""},
         {"g": "演示剧本时刻 (s)"},
         {"name": "fault_at", "label": "短路时刻 s", "type": "number", "default": 0.45, "min": 0.1, "max": 2.5, "step": 0.05},
         {"name": "fault_R", "label": "短路电阻 Ω", "type": "number", "default": 0.4, "min": 0.05, "max": 5, "step": 0.05},
         {"name": "reset_at", "label": "报警复位时刻 s", "type": "number", "default": 0.75, "min": 0.2, "max": 2.8, "step": 0.05},
         {"name": "restart_at", "label": "再启动时刻 s", "type": "number", "default": 0.85, "min": 0.3, "max": 2.9, "step": 0.05},
         {"name": "t_end", "label": "仿真时长 s", "type": "number", "default": 1.6, "min": 0.5, "max": 3.0, "step": 0.1},
     ],
     "run": _mcu},
]




def run_circuit(params, progress):
    from rw.circuit import examples as EX, scope as sc, spice, kicad
    if not spice.find_ngspice():
        raise ValueError("服务器未安装 ngspice，电路仿真暂不可用。安装：sudo apt install ngspice（或设 RW_NGSPICE 指向可执行文件）")
    custom = (params.get("custom_netlist") or "").strip()
    lines, warns, raw_meas = [], [], {}
    progress(0.1)
    if custom:
        c = kicad.import_spice(None, text=custom)
        w = c.tran(step=float(params.get("tstep", 1e-5)), stop=float(params.get("tstop", 1e-2)))
        name, theory, chans, wa = "自定义网表", "", (w.nets() or [])[:4], None
    else:
        ex = EX.get(params.get("example") or "rc")
        name, theory = ex.name, ex.theory
        w = ex.circuit.tran(**ex.tran)
        chans = [n for n, _, _ in ex.scope["ch"]]
        wa = ex.circuit.ac(**ex.ac) if ex.ac else None
    progress(0.7)
    lines.append(f"{name}（瞬态 {len(w.x)} 点）")
    if theory:
        lines.append(f"理论：{theory}")

    def _eng(v, unit):
        return "-" if v is None else f"{spice.fmt(v)}{unit}"

    for ch in chans:
        try:
            y = np.asarray(w[ch], float)
        except KeyError:
            continue
        m = sc.measure(w.time, y)
        raw_meas[ch] = dict(m)
        parts = [f"Vpp {_eng(m.get('Vpp'), 'V')}", f"Vrms {_eng(m.get('Vrms'), 'V')}"]
        if m.get("频率"):
            parts.append(f"f {_eng(m['频率'], 'Hz')}")
        if m.get("占空比") is not None:
            parts.append(f"占空比 {m['占空比'] * 100:.1f}%")
        if m.get("上升时间"):
            parts.append(f"tr {_eng(m['上升时间'], 's')}")
        lines.append(f"· {ch}：" + "，".join(parts))
    warns += list(w.warnings)

    plots = []
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for ch in chans:
        try:
            ax.plot(w.time, w[ch], lw=1.2, label=ch)
        except KeyError:
            pass
    ax.set_xlabel("t (s)"); ax.set_ylabel("V")
    ax.legend(fontsize=9); ax.set_title(f"{name} · 瞬态波形")
    plots.append({"title": "波形图", "svg": _svg(fig)})
    if chans:
        try:
            f, db, _ = sc.fft_dbv(w.time, np.asarray(w[chans[0]], float))
            fig, ax = plt.subplots(figsize=(7, 3.2))
            ax.semilogx(f[1:], db[1:], lw=1)
            ax.set_xlabel("f (Hz)"); ax.set_ylabel("dBV"); ax.set_title(f"{chans[0]} 频谱")
            plots.append({"title": "频谱", "svg": _svg(fig)})
        except Exception as e:
            warns.append(f"频谱计算失败：{e}")
    if wa is not None:
        node = chans[-1] if chans and chans[-1] in wa.nets() else (wa.nets() or [None])[-1]
        v = np.asarray(wa[node])
        fig, (a1, a2) = plt.subplots(2, 1, figsize=(7, 4.6), sharex=True)
        a1.semilogx(wa.freq, 20 * np.log10(np.maximum(np.abs(v), 1e-15)), lw=1.2); a1.set_ylabel("dB"); a1.grid(True, alpha=.3)
        a2.semilogx(wa.freq, np.degrees(np.angle(v)), lw=1.2); a2.set_ylabel("°"); a2.set_xlabel("f (Hz)"); a2.grid(True, alpha=.3)
        a1.set_title(f"{node} 频率响应")
        plots.append({"title": "频率响应", "svg": _svg(fig)})
    progress(1.0)
    return {"lines": lines, "warnings": warns, "plots": plots, "raw": {"measurements": raw_meas, "points": len(w.x)}}


MODULES.append({"key": "circuit", "name": "电路仿真", "desc": "示例电路或自定义 SPICE 网表 → ngspice 瞬态/交流仿真 → 自动测量（Vpp/Vrms/频率/占空比/上升时间）+ 波形/频谱/频率响应图（需服务器装 ngspice）",
    "fields": [
        {"name": "example", "label": "示例电路", "type": "select", "default": "rc",
         "options": [{"v": "rc", "t": "RC 方波响应"}, {"v": "rlc", "t": "RLC 串联谐振"}, {"v": "rect", "t": "桥式整流 + 电容滤波"}, {"v": "astable", "t": "运放方波振荡器"}, {"v": "halfbridge", "t": "MOSFET 半桥 + 串联谐振"}]},
        {"name": "custom_netlist", "label": "自定义 SPICE 网表（可选，填了就忽略示例）", "type": "textarea", "default": ""},
        {"name": "tstep", "label": "自定义：步长 s", "type": "number", "default": 1e-5, "min": 1e-9, "max": 1e-1, "step": 1e-6},
        {"name": "tstop", "label": "自定义：终止 s", "type": "number", "default": 1e-2, "min": 1e-6, "max": 10.0, "step": 1e-3},
    ],
    "run": run_circuit})
